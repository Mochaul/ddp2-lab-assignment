
public class StafIT extends Staf{
	public StafIT(String nama, String gender) {
		super(nama, gender);
	}
}
