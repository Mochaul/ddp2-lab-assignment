
public class Janitor extends Karyawan{
	
	public Janitor(String nama, String gender) {
		super(nama, gender, 4000000);
	}
}
