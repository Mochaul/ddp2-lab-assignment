
public class StafHRD extends Staf{
	public StafHRD(String nama, String gender) {
		super(nama, gender);
	}
}
