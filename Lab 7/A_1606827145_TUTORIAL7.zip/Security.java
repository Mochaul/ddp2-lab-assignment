
public class Security extends Karyawan{
	
	public Security(String nama, String gender) {
		super(nama, gender, 3500000);
	}
}
