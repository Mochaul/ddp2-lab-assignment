
public class Staf extends Karyawan{
	
	public Staf(String nama, String gender) {
		super(nama, gender, 5000000);
	}
}
